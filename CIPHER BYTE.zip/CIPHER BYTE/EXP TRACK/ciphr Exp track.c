#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char date[11];    
    char category[30];
    float amount;
    char description[100];
} Expense;

void addExpense();
void viewExpenses();
void generateReport();
void saveToFile(Expense expense);
void loadFromFile();
void displayMenu();

int main() {
    int choice;

    loadFromFile(); 

    while (1) {
        displayMenu();
        scanf("%d", &choice);
        getchar();  

        switch (choice) {
            case 1:
                addExpense();
                break;
            case 2:
                viewExpenses();
                break;
            case 3:
                generateReport();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}

void displayMenu() {
    printf("\nExpense Tracker\n");
    printf("1. Add Expense\n");
    printf("2. View Expenses\n");
    printf("3. Generate Report\n");
    printf("4. Exit\n");
    printf("Enter your choice: ");
}

void addExpense() {
    Expense expense;

    printf("Enter date (YYYY-MM-DD): ");
    scanf("%s", expense.date);
    printf("Enter category: ");
    scanf("%s", expense.category);
    printf("Enter amount: ");
    scanf("%f", &expense.amount);
    getchar();  
    printf("Enter description: ");
    fgets(expense.description, sizeof(expense.description), stdin);
    expense.description[strcspn(expense.description, "\n")] = '\0';  

    saveToFile(expense);
    printf("Expense added successfully!\n");
}

void viewExpenses() {
    FILE *file = fopen("expenses.txt", "r");
    Expense expense;

    if (!file) {
        printf("No expenses found.\n");
        return;
    }

    printf("\nDate       | Category      | Amount   | Description\n");
    printf("---------------------------------------------------\n");

    while (fread(&expense, sizeof(Expense), 1, file)) {
        printf("%-10s | %-12s | %-8.2f | %s\n", expense.date, expense.category, expense.amount, expense.description);
    }

    fclose(file);
}

void generateReport() {
    FILE *file = fopen("expenses.txt", "r");
    Expense expense;
    float total = 0;

    if (!file) {
        printf("No expenses found.\n");
        return;
    }

    while (fread(&expense, sizeof(Expense), 1, file)) {
        total += expense.amount;
    }

    printf("\nTotal expenses: %.2f\n", total);

    fclose(file);
}

void saveToFile(Expense expense) {
    FILE *file = fopen("expenses.txt", "a");

    if (file) {
        fwrite(&expense, sizeof(Expense), 1, file);
        fclose(file);
    } else {
        printf("Error saving expense.\n");
    }
}

void loadFromFile() {
}
