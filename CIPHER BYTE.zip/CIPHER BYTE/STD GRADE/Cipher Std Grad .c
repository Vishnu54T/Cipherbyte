#include<stdio.h>
int main()
{
	int numSubjects;
	printf("Enter the number of subjects:");
	scanf("%d",&numSubjects);
	
	if(numSubjects<=0)
	{
		printf("Invalid numbers of subjects\n");
		return 1;
	}
	
	float grades[numSubjects];
	float sum=0.0;
	
	for(int i=0;i<numSubjects;i++)
	{
		printf("Enter grade for subject %d: ",i+1);
		scanf("%f",&grades[i]);
		sum+=grades[i];
	}
	
	float average=sum/numSubjects;
	printf("The average grade is: %.2f\n",average);
	
	return 0;
}

